rm -rf .git
git init --initial-branch=main
sleep 2
git remote add origin https://gitlab.com/adrian.m.miller/disablegoogleanalytics.git
sleep 2
git add .
sleep 2
git commit -m "Initial commit"
sleep 2
git push --set-upstream origin main
